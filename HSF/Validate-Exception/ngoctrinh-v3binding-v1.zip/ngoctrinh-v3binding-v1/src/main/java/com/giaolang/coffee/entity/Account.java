package com.giaolang.coffee.entity;

public class Account {
}
