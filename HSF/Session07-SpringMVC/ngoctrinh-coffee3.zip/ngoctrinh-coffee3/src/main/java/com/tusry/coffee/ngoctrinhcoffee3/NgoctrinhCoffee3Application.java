package com.tusry.coffee.ngoctrinhcoffee3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgoctrinhCoffee3Application {

    public static void main(String[] args) {
        SpringApplication.run(NgoctrinhCoffee3Application.class, args);
    }

}
